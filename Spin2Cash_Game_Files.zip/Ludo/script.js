function play() {
    alert("Playing Ludo game...");
}