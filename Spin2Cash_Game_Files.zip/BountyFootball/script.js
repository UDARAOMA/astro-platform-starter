function play() {
    alert("Playing BountyFootball game...");
}