function play() {
    alert("Playing Spin game...");
}