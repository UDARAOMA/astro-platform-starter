function play() {
    alert("Playing Puzzle game...");
}